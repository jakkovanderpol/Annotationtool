<?php

//include 'config/testing.php';
include 'config/production.php';

include 'config/main.php';
