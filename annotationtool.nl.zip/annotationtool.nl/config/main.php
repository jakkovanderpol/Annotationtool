<?php

$app += array(
	'default_module' => 'main',	
	'master_template' => 'master',
	'dialog_template' => 'dialog',
	'mail_server' => 'localhost',
	'mail_from_name' => 'Annotatiesysteem',
	'mail_from_address' => 'noreply@annotatiesysteem.nl',
		'default_language' => 'en'
);
