<?php

$app = array(
	'db_url' => 'mysql://annotatie:jrdp1mUZ295qxiUDVEyf@localhost/annotatie_demo',
	'mail_from_name' => 'Annotatiesysteem',
	'mail_from_address' => 'noreply@annotatiesysteem.nl',
	'mail_to_debug' => null,
	'host' => 'test.annotatiesysteem.nl'
);
