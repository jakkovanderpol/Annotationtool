<?php

//directory naam gebruiker voor db naam
$db_name = array_pop(split('/',realpath('.')));

$app = array(
	'db_url' => 'mysql://root:@localhost/'.$db_name
);
