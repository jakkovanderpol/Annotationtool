<?php
error_reporting(E_ALL);

/*
$result = @fopen('tmp/convert.lock', 'x');

if($result === false) {
	echo "process already active\n";
} else {
	fclose($result);
*/
	// perform ye magick
//file_put_contents("convert_log.txt", "convert.php called @ ". date("d-m-Y H:i:s") . PHP_EOL, FILE_APPEND);
	include 'config/includes.php';
	require('core/init.php');
	
	// zoek een queued document
	$j = 0;

	
    while($j<60) {
        sleep( 1 );

        $documents = document::select(array('status' => 'queued'));

        if(count($documents) > 0) {
            $document = $documents[0];

            $id = $document->id;

            echo "converting document #" . $id . ": " . $document->question . "...\n";

            $document->status = 'pending';
            $document->update();

            set_time_limit(0);

            $i = 0;
            // while loop moet blijven omdat het process anders teveel geheugen gebruikt bij grote pdf's -resize extre, -trim weg...
            while($i < 1000) {
            	@shell_exec("cd upload/document-$id/; convert -density 200 -resize 52% -trim +repage +adjoin original.pdf[$i] page-$i.gif");
    //          @shell_exec("cd upload/document-$id/; convert -interword-spacing 1 -density 100 -gravity center -kerning -0.5 -trim +repage +adjoin original.pdf[$i] page-$i.gif");
    //          @shell_exec("cd upload/document-$id/; convert -density 200 -resample 92% -trim -sharpen 0.5 +repage +adjoin original.pdf[$i] page-$i.gif");
    //          @shell_exec("cd upload/document-$id/; convert -density 200 -resample 92% -trim +repage +adjoin original.pdf[$i] page-$i.gif");
    //			@shell_exec("cd upload/document-$id/; convert -density 92 -trim  +repage +adjoin \"original.pdf[$i]\" page-$i.gif");
    //			@shell_exec("cd upload/document-$id/; convert -density 180 -trim -resize 550 +repage +adjoin \"original.pdf[$i]\" page-$i.gif");

                if(file_exists("upload/document-$id/page-$i.gif")) {
                    $i++;
                } else {
                    break;
                }
            }

            $document->num_pages = $i;
            $document->status = 'ready';
            $document->update();
        }

        $j++;
    }

/*
    unlink("tmp/convert.lock");
}
*/
