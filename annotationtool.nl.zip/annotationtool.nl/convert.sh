#!/bin/sh

cd /var/www/annotatiesysteem.nl
php convert.php
