<?php

function core_override_master_template ($new_template) {
	global $core_master_template_override;
	$core_master_template_override = $new_template;
}


function core_init_session() {
	global $app;

	if (isset($app['session_name'])) {
		session_name ($app['session_name']);
	}
	if (isset($app['session_lifetime'])) {
//		session_cache_expire( $app['session_lifetime'] );
//		session_set_cookie_params ( 60 * $app['session_lifetime'] );
	}
	
	session_start();
}

function core_init_db() {
	global $app;

	/* database initialisatie */

	// waarom dit niet netter kan moet je aan de jongens en meisjes van PHP.net vragen
	$GLOBALS['db'] = DB::connect(
		$app['db_url'],
		array(
			'debug'       => 2
		)
	);
	if (PEAR::isError($GLOBALS['db'])) {
		trigger_error($GLOBALS['db']->getMessage(), E_USER_ERROR);
	}
	$GLOBALS['db']->setFetchmode(DB_FETCHMODE_ASSOC);
}

