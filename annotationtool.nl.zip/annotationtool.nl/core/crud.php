<?php

class crud extends page {
	function validate() {
		$has_errors = false;
		
		$class = $this->class;
		
		foreach($this->validate as $field => $type) {
			if($type == 'password') {
				if($this->repeat_password != $this->record[$field]) {
					$this->errors['repeat_password'] = true;
					$has_errors = true;
				}
			}
			
			$function = "validate_$type";
			
			if($type == 'unique_username') {
				$valid = $function($this->record[$field], $this->id);
			} else {
				$valid = $function($this->record[$field]);
			}
			
			if(!$valid) {
				$this->errors[$field] = true;
				$has_errors = true;
			}
		}
		
		return !$has_errors;
	}
	
	function get_parent($class, $id) {
		return call_user_func(array($class, 'from_id'), $id);
	}
	
	function add_parent($class) {
		$class_id = $class . '_id';
		$id = $this->$class_id;
		
		$this->$class = $this->get_parent($class, $id);
	}
	
	function get_children($class, $field, $parent_id) {
		return call_user_func(array($class, 'select'), array($field => $this->parent_id));
	}
}
