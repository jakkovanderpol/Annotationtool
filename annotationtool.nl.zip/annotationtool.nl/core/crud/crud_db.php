<?php

class crud_db {
	function show() {
		$this->visible = 'true';
		$this->update();
	}
	
	function hide() {
		$this->visible = 'false';
		$this->update();
	}
	
	function from_row($row, $class) {
		if (PEAR::isError($row)) {
			die($row->getDebugInfo());
		} elseif($row === false || $row === null) {
			return false;
		} else {
			$record = new $class();
			
			foreach($row as $key => $value) {
				$record->$key = $value;
			}
			
			return $record;
		}
	}

	function from_values($values, $class) {
		$record = new $class();
		
		foreach($values as $key => $value) {
			$record->set_value($key, $value);
		}
		
		return $record;
	}
	
	function array_from_id($id, $table) {
		global $db;
		
		$sql = "SELECT * FROM `$table` WHERE id = ?";
		$data = array($id);
		
		$row = $db->getRow($sql, $data, DB_FETCHMODE_ASSOC);
		
		return $row;
	}
	
	function from_id($id, $class) {
		$row = call_user_func(array($class, 'array_from_id'), $id);
		
		return call_user_func(array($class, 'from_row'), $row);
	}
	
	function from_result($result, $class) {
		$return = array();
		
		foreach($result as $row) {
			$return[] = call_user_func(array($class, 'from_row'), $row);
		}
		
		return $return;
	}
	
	function select($filter, $table) {
		$class = $table;
		
		$result = crud_db::get_all($filter, $table);
		
		if (PEAR::isError($result)) {
			die($result->getDebugInfo());
		} else {
			return crud_db::from_result($result, $class);
		}
	}
	
	function get_all($filter, $table, $sort=true)
	{
		global $db;
		
		$sql = "SELECT * FROM `$table`";
		$data = array();
		
		if(count($filter) > 0) {
			$filter = crud_db::get_filter($filter);
			$sql .= $filter['sql'];
			$data = array_merge($data,$filter['data']);
		}
		
		/*if($sort) {
			$sql .= " ORDER BY id";
		}*/
		
		return $db->getAll($sql, $data, DB_FETCHMODE_ASSOC);
	}
	
	function assoc_list($field, $filter, $table) {
		$records = crud_db::select($filter, $table);
		$list = array();
		
		foreach($records as $record) {
			$list[$record->id] = $record->$field;
		}
		
		return $list;
	}
	
	function get_filter($filter, $class = null, $addition = false) {
		$result = array('sql'=>'','data'=>array());
		
		if (is_array($filter)) {
			$uses_keyword = false;
			
			//WHERE
			if (isset($filter['where']) && is_array($filter['where'])) {
				$uses_keyword = true;
				
				$result['sql'] .= ($addition)?" AND ":" WHERE ";
				
				$i = 0;
				foreach($filter['where'] as $key=>$value) {
					if (strpos($key,'.') === false && $class) {
						$key = $class.'`.`'.$key;
					}
					if ($i != 0) {
						$result['sql'] .= " AND ";
					}
					if (is_array($value)) {
						$result['sql'] .= '`'.$key.'` '.' '.$value[0].' ?';
						$result['data'][] = $value[1];
					} else {
						$result['sql'] .= '`'.$key.'` '.' '.(($value===null)?'is':'=').' ?';
						$result['data'][] = $value;
					}
					$i++;
				}
				
			} else if (isset($filter['where']) && $filter['where'] != "") {
				$uses_keyword = true;
				
				$result['sql'] .= ($addition)?" AND ":" WHERE ";
				
				$result['sql'] .= $filter['where'];
			}
			
			//ORDER
			if (isset($filter['order']) && is_array($filter['order'])) {
				$uses_keyword = true;
				
				$result['sql'] .= ' ORDER BY ';
				foreach($filter['order'] as $i=>$order) {
					if ($i != 0) {
						$result['sql'] .= ", ";
					}
					$result['sql'] .= $order;
				}
			} else if (isset($filter['order']) && $filter['order'] != "") {
				$uses_keyword = true;
				
				$result['sql'] .= ' ORDER BY '.$filter['order'];
			}
			
			//LIMIT
			if (isset($filter['limit']) && is_array($filter['limit'])) {
				$uses_keyword = true;
				
				$result['sql'] .= ' LIMIT '.$filter['limit'][0].', '.$filter['limit'][1];
			} else if (isset($filter['limit']) && $filter['limit'] != "") {
				$uses_keyword = true;
				
				$result['sql'] .= ' LIMIT '.$filter['limit'];
			}
			
			//SIMPLE WHERE
			if ($uses_keyword === false) {
				$result['sql'] .= ($addition)?" AND ":" WHERE ";
				
				$i = 0;
				foreach($filter as $key=>$value) {
					if (strpos($key,'.') === false && $class) {
						$key = $class.'`.`'.$key;
					}
					if ($i != 0) {
						$result['sql'] .= " AND ";
					}
					if (is_array($value)) {
						$result['sql'] .= '`'.$key.'` '.$value[0].' ?';
						$result['data'][] = $value[1];
					} else {
						if (is_numeric($key)) {
							$result['sql'] .= $value;
						} else {
							$result['sql'] .= '`'.$key.'` '.' '.(($value===null)?'is':'=').' ?';
							$result['data'][] = $value;
						}
					}
					$i++;
				}
			}
			
		} else {
			
			$result['sql'] .= $filter;
			
		}
		return $result;
	}

	function update($table) {
		global $db;
		
		$values = $this->to_quoted_array();
		unset($values['id']);
		
		$where = 'id = ' . intval($this->id);
		$mode = DB_AUTOQUERY_UPDATE;
		
		$result = $db->autoExecute("`$table`", $values, $mode, $where);
		
		if(PEAR::isError($result)){
			return $result;
		} else {
			return true;
		}
	}
	
	function to_array() {
		$array = array();
		
		foreach($this as $key => $value) {
			$array[$key] = $value;
		}
		
		return $array;
	}

	function to_quoted_array() {
		$array = array();
		
		foreach($this->to_array() as $key => $value) {
			$array["`$key`"] = $value;
		}
		
		return $array;
	}

	function set_value($field, $value) {
		$this->$field = $value;
	}

	function insert($table) {
		global $db;
		
		$values = $this->to_quoted_array();
		unset($values['id']);
		
		$mode = DB_AUTOQUERY_INSERT;
		
		$result = $db->autoExecute("`$table`", $values, $mode);
		
		$this->id = mysql_insert_id($db->connection);
		
		if(PEAR::isError($result)){
			return $result;
		} else {
			return true;
		}
	}
	
	function auto_insert($values, $table)
	{
		global $db;
		
		return $db->autoExecute("`$table`", $values, DB_AUTOQUERY_INSERT);
	}
	
	function auto_delete($filter, $table)
	{
		global $db;
		
		$sql = "DELETE FROM `$table`";
		$data = array();
		
		if(count($filter) > 0) {
			$first = true;
			
			foreach($filter as $key => $value) {
				if($first) {
					$sql .= " WHERE `$key` = ?";
					$first = false;
				} else {
					$sql .= " AND `$key` = ?";
				}
				
				$data[] = $value;
			}
		}
		
		return $db->query($sql, $data);
	}
	
	function delete($table) {
		global $db;
		
		$sql = "DELETE FROM `$table` WHERE id = ?";
		$data = array($this->id);
		
		$result = $db->query($sql, $data);
		
		return $result;
	}
	
	function single_delete($table) {
		return crud_db::delete($table);
	}
}
