<?php

class crud_delete extends crud {
	var $id;
	var $class;
	var $fields;
	var $validate;
	var $errors = array();

	var $delete_redirect = null;
	var $cancel_redirect = null;
	
	function on_delete($record) {}
	
	function process() {
		
		
		$action = $this->get_action();
		$class = $this->class;

		if($action == 'delete') {
			global $db;
			$this->id = $db->escapeSimple($_GET['course_id']);
			$this->delete_redirect = 'group.index&course_id='.$this->id;
			$this->cancel_redirect = 'group.index&course_id='.$this->id;
			
			$user = user::from_session();
			
			if($user->id){
				// delete annotations from course
				$res = $db->query("SELECT * FROM `annotation` WHERE annotation.heading_id IN (
										SELECT heading.id FROM `heading` WHERE heading.document_id IN (
											SELECT document.id FROM `document` WHERE document.group_id IN (
												SELECT group.id FROM `group` 
												LEFT JOIN user_group ON user_group.group_id = group.id
												WHERE group.course_id IN (
												    SELECT course.id FROM `course` WHERE course.id = ?
												) AND user_group.user_id = ?
	    									)
	    								)
	    							)", array($this->id, $user->id));
			
	
				if (PEAR::isError($res) || count($res) == 0) {
					die($res->getMessage());
				}
				
				while ($row = $res->fetchRow()) {
					if(!is_null(annotation::from_id($row['id']))){
						annotation::from_id($row['id'])->delete();
					}
				}
					
				// delete students from course
				$res = $db->query("SELECT user.id FROM user WHERE user.id IN ( 
									SELECT user_group.user_id FROM user_group WHERE user_group.group_id IN ( 
										SELECT group.id FROM `group` 
												LEFT JOIN user_group ON user_group.group_id = group.id
												WHERE group.course_id IN (
												    SELECT course.id FROM `course` WHERE course.id = ?
												) AND user_group.user_id = ?
									) 
								   ) AND user.userlevel = \"student\"", array($this->id, $user->id));			
					
				if (PEAR::isError($res)) {
					die($res->getMessage());
				}
					
				while ($row = $res->fetchRow()) {
					if(!is_null(user::from_id($row['id']))){
						user::from_id($row['id'])->delete();
					}
				}
			}else{
				die("You must login to complete this action" . var_dump($userId));
			}
			$this->on_delete($record);		
			$this->redirect($this->delete_redirect);

		} elseif($action == 'cancel') {
			$this->redirect($this->cancel_redirect);
		} else {
			$this->record = call_user_func(array($class, 'array_from_id'), $this->id);
		}
	}
}
