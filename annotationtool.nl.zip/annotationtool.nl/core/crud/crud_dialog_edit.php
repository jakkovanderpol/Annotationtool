<?php

class crud_dialog_edit extends crud_dialog {
	var $id;
	var $class;
	var $fields;
	var $validate;
	var $errors = array();
	
	function on_update($record) {}

	function load_record() {
		$record = call_user_func(array($this->class, 'from_id'), $this->id);
		return $record;
	}
	
	function process() {
		$action = $this->get_action();
		$class = $this->class;
		
		if($action == 'save') {
			$record = $this->load_record();
			
			foreach($this->fields as $field) {
				$record->set_value($field, isset($this->record[$field])?$this->record[$field]:"");
			}
			
			if($this->validate()) {
				$record->update();
				
				$this->on_update($record);
				$this->refresh();
			} else {
				$this->record = $record->to_array();
			}
		} elseif($action == 'cancel') {
			$this->close();
		} else {
			$this->record = call_user_func(array($class, 'array_from_id'), $this->id);
		}
	}

	function get_request_variables(){
		return array('id', 'record');	
	}
	
}
