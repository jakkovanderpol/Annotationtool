<?php

class crud_dialog_new extends crud_dialog {
	var $id = null;
	var $class;
	var $fields;
	var $validate;
	var $errors = array();
	var $default = array();
	
	function on_insert($record) {}
	
	function process() {
		$action = $this->get_action();
		$class = $this->class;
		
		if(!is_array($this->record)) {
			$this->record = array();
		}
		
		$this->record += $this->default;
		
		if($action == 'save') {
			if($this->validate()) {
				$values = array();

				foreach($this->fields as $field) {
					$values[$field] = isset($this->record[$field])?$this->record[$field]:"";
				}
				
				$values += $this->default;
				
				$record = call_user_func(array($class, 'from_values'), $values);
				$record->insert();
				
				$this->on_insert($record);
				$this->refresh();
			}
		} elseif($action == 'cancel') {
			$this->close();
		}
	}

	function get_request_variables(){
		return array('record');	
	}
}
