<?php

class crud_list extends crud {
	var $class;
	var $filter = array();
	
	var $edit_redirect;
	var $new_redirect;
	var $clean_redirect;
	
	function __construct() {
		parent::__construct();
		
		if(!isset($this->clean_redirect)) {
			$array = $_GET;
			
			unset($array['m']);
			unset($array['ids']);
			
			foreach($array as $key => $value) {
				if(substr($key, 0, 7) == 'submit_') {
					unset($array[$key]);
				}
			}
			
			$query_string = array2querystring($array);
			
			$this->clean_redirect = $_REQUEST['m'] . '&' . $query_string;
		}
	}
	
	function get_data() {
		$class = $this->class;
		return call_user_func(array($class, 'select'), $this->filter);
	}
	
	function get_records() {
		$class = $this->class;
		$records = array();

		foreach($this->ids as $id) {
			$records[] = call_user_func(array($class, 'from_id'), $id);
		}
		
		return $records;
	}
	
	function process() {
		$action = $this->get_action();
		$class = $this->class;

		if($action === 'edit') {
			$this->redirect($this->edit_redirect, array('id' => $this->ids[0]));
		} elseif($action === 'new') {
			$this->redirect($this->new_redirect);
		} elseif($action === 'del') {
			$records = $this->get_records();

			foreach($records as $record) {
				$record->delete();
			}

			$this->redirect($this->clean_redirect);
		} elseif($action === 'single_del') {
			$records = $this->get_records();

			foreach($records as $record) {
				$record->single_delete();
			}

			$this->redirect($this->clean_redirect);
		} elseif($action === 'show') {
			$records = $this->get_records();
			
			foreach($records as $record) {
				$record->show();
			}
			
			$this->redirect($this->clean_redirect);
		} elseif($action === 'hide') {
			$records = $this->get_records();
			
			foreach($records as $record) {
				$record->hide();
			}
			
			$this->redirect($this->clean_redirect);
		} else {
			$this->data = $this->get_data();
		}
	}
	
	function get_request_variables(){
		return array('ids');	
	}
}
