<?php

class crud_sortable_list extends crud_list {
	var $sort_key = null;
	var $sort_order = null;

	function validate_sort_key($key) {
		return in_array($key, array_keys($this->allowed_sort));
	}

	function cmp($el1,$el2) {
		$field = $this->allowed_sort[$this->sort_key];
		$res= ($this->sort_order?-1:1)*strcmp($el1->$field,$el2->$field);
		return $res;
	}

	function sort(&$data,$order,$key) {
		$this->sort_key = $key;
		$this->sort_order = $order;
		usort($data, array($this,'cmp'));
		$this->sort_key = null;
		$this->sort_order = null;
	}
}