<?php

class crud_db {
	function from_row($row, $class) {
		if (PEAR::isError($row)) {
			die($row->getDebugInfo());
		} elseif($row === false || $row === null) {
			return false;
		} else {
			$record = new $class();
			
			foreach($row as $key => $value) {
				$record->$key = $value;
			}
			
			return $record;
		}
	}

	function from_values($values, $class) {
		$record = new $class();
		
		foreach($values as $key => $value) {
			$record->set_value($key, $value);
		}
		
		return $record;
	}
	
	function array_from_id($id, $table) {
		global $db;
		
		$sql = "SELECT * FROM `$table` WHERE id = ?";
		$data = array($id);
		
		$row = $db->getRow($sql, $data, DB_FETCHMODE_ASSOC);
		
		return $row;
	}
	
	function from_id($id, $class) {
		$row = call_user_func(array($class, 'array_from_id'), $id);
		
		return call_user_func(array($class, 'from_row'), $row);
	}
	
	function select($filter, $table) {
		global $db;
		
		$class = $table;
		
		$sql = "SELECT * FROM `$table`";
		$data = array();
		
		if(count($filter) > 0) {
			$first = true;
			
			foreach($filter as $key => $value) {
				if($first) {
					$sql .= " WHERE `$key` = ?";
					$first = false;
				} else {
					$sql .= " AND `$key` = ?";
				}
				
				$data[] = $value;
			}
		}
		
		$result = $db->getAll($sql, $data, DB_FETCHMODE_ASSOC);
		
		if (PEAR::isError($result)) {
			die($result->getDebugInfo());
		} else {
			$return = array();
			
			foreach($result as $row) {
				$return[] = call_user_func(array($class, 'from_row'), $row);
			}
			
			return $return;
		}
	}

	function update($table) {
		global $db;
		
		$values = $this->to_array();
		unset($values['id']);
		
		$where = 'id = ' . intval($this->id);
		$mode = DB_AUTOQUERY_UPDATE;
		
		$result = $db->autoExecute("`$table`", $values, $mode, $where);
		
		if(PEAR::isError($result)){
			return $result;
		} else {
			return true;
		}
	}
	
	function to_array() {
		$array = array();
		
		foreach($this as $key => $value) {
			$array[$key] = $value;
		}
		
		return $array;
	}

	function set_value($field, $value) {
		$this->$field = $value;
	}

	function insert($table) {
		global $db;
		
		$values = $this->to_array();
		unset($values['id']);
		
		$mode = DB_AUTOQUERY_INSERT;
		
		$result = $db->autoExecute("`$table`", $values, $mode);
		
		$this->id = mysql_insert_id($db->connection);
		
		if(PEAR::isError($result)){
			return $result;
		} else {
			return true;
		}
	}
}