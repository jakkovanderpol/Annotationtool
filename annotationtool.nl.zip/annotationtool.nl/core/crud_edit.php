<?php

class crud_edit extends crud {
	var $id;
	var $class;
	var $fields;
	var $validate;
	var $errors = array();
	
	var $save_redirect = null;
	var $cancel_redirect = null;
	
	function on_update($record) {}
	
	function process() {
		$action = $this->get_action();
		$class = $this->class;
		
		if($action == 'save') {
			$record = call_user_func(array($class, 'from_id'), $this->id);
			
			foreach($this->fields as $field) {
				$record->set_value($field, $this->record[$field]);
			}
			
			if($this->validate()) {
				$record->update();
				
				$this->on_update($record);
				$this->redirect($this->save_redirect);
			} else {
				$this->record = $record->to_array();
			}
		} elseif($action == 'cancel') {
			$this->redirect($this->cancel_redirect);
		} else {
			$this->record = call_user_func(array($class, 'array_from_id'), $this->id);
		}
	}
}
