<?php

class crud_list extends crud {
	var $class;
	var $filter = array();
	
	var $edit_redirect;
	var $new_redirect;
	
	function process() {
		$action = $this->get_action();
		$class = $this->class;
		
		if($action == 'edit') {
			$this->redirect($this->edit_redirect, array('id' => $this->record_id));
		} elseif($action == 'new') {
			$this->redirect($this->new_redirect);
		} elseif($action == 'del') {
			call_user_func(array($class, 'delete'), $this->record_id);
			
			$this->redirect();
		} else {
			$this->data = call_user_func(array($class, 'select'), $this->filter);
		}
	}
}
