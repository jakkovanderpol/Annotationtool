<?php

class crud_new extends crud {
	var $id = null;
	var $class;
	var $fields;
	var $validate;
	var $errors = array();
	var $default = array();
	
	var $save_redirect = null;
	var $cancel_redirect = null;

	function on_insert($record) {}
	
	function process() {
		$action = $this->get_action();
		$class = $this->class;
		
		if(!is_array($this->record)) {
			$this->record = array();
		}
		
		$this->record += $this->default;
		
		if($action == 'save') {
			$record = call_user_func(array($class, 'from_values'), $this->record);
			
			if($this->validate()) {
				$record->insert();
				
				$this->on_insert($record);
				
				$this->redirect($this->save_redirect);
			}
		} elseif($action == 'cancel') {
			$this->redirect($this->cancel_redirect);
		}
	}
}
