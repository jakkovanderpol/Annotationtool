<?php

require_once 'core/libs/swiftmailer/lib/Swift.php';
require_once 'core/libs/swiftmailer/lib/Swift/Connection/SMTP.php';

class developer_code_mailer {
	var $connection, $swift;
	
	function developer_code_mailer() {
		global $app;
		
		$this->connection = new Swift_Connection_SMTP($app['mail_server']);
		$this->swift = new Swift($this->connection);
		
		$this->from = new Swift_Address($app['mail_from_address'], $app['mail_from_name']);
	}
	
	function send($to_address, $to_name, $subject, $body) {
		global $app;
		
		if($app['mail_to_debug'] === null) {
			$message = new Swift_Message($subject, $body, "text/html");
			$to = new Swift_Address($to_address, $to_name);
			return $this->swift->send($message, $to, $this->from);
		} else {
			$message = new Swift_Message($subject, $body, "text/html");
			$to = new Swift_Address($app['mail_to_debug'], $to_name . " (" . $to_address . ")");		
			return $this->swift->send($message, $to, $this->from);
		}
	}
}
