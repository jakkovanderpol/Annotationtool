<?php

// AJAX dialog!

class dialog extends page {
	function __construct() {
		global $app;
		
		parent::__construct();
		$this->master_template = $app['dialog_template'];
	}
	
	function hard_redirect($uri) {
		$json = new Services_JSON(SERVICES_JSON_LOOSE_TYPE);
		$array = array('action' => 'redirect', 'uri' => $uri);
		
		echo($json->encode($array));
		
		exit();
	}
	
	function refresh() {
		$json = new Services_JSON(SERVICES_JSON_LOOSE_TYPE);
		$array = array('action' => 'refresh');
		
		echo($json->encode($array));
		
		exit();
	}
	
	function close() {
		$json = new Services_JSON(SERVICES_JSON_LOOSE_TYPE);
		$array = array('action' => 'close');
		
		echo($json->encode($array));
		
		exit();
	}
	
	function render() {
		$json = new Services_JSON(SERVICES_JSON_LOOSE_TYPE);
		$html = page::render();
		$array = array('action' => 'display', 'html' => $html);
		
		return $json->encode($array);
	}
	
	function dump($text) {
		$json = new Services_JSON(SERVICES_JSON_LOOSE_TYPE);
		$html = htmlspecialchars($text);
		$array = array('action' => 'display', 'html' => $html);
		
		echo($json->encode($array));
		
		exit();
	}
}