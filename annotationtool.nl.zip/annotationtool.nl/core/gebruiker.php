<?php

function gebruiker_login ($login, $wachtwoord) {
	$gebruiker_id = gebruiker_identify ($login, $wachtwoord);

	if ($gebruiker_id) {
		gebruiker_register($gebruiker_id);
		return true;
	} else {
		return false;
	}
}

function gebruiker_identify ($login, $wachtwoord){
	global $db;
	$user = $db->getOne('SELECT id FROM users WHERE gebruikersnaam=? AND wachtwoord=MD5(?) AND inactief=0', array( $login, $wachtwoord ), DB_FETCHMODE_ASSOC);
	if(PEAR::isError($user)){
		$user = null;
	}
	return $user;
		
}

function gebruiker_get ($gebruiker_id=null) {
        global $db;

        if (is_null($gebruiker_id)) {
                $gebruiker_id = gebruiker_get_id();
        }

        $ret = array();
        $gebruiker_row = $db->getRow('SELECT * FROM users WHERE id=?', array($gebruiker_id), DB_FETCHMODE_ASSOC);

        if (PEAR::isError($gebruiker_row)) {
                die($gebruiker_row->getDebugInfo());
        }

        return $gebruiker_row;
}


function gebruiker_register($gebruiker_id) {
	$_SESSION['gebruiker_id']    = $gebruiker_id;
		
	$gebruiker_row = gebruiker_get ($gebruiker_id);
	$_SESSION['gebruiker_recht'] = $gebruiker_row['status'];

	foreach($gebruiker_row as $field => $value) {
		if(substr($field, 0, 6) == 'recht_') {
			$_SESSION[$field] = $value;
		}
	}
}

function gebruiker_logout () {
	unset ($_SESSION['gebruiker_id']);
	unset ($_SESSION['gebruiker_recht']);
}

function gebruiker_get_id () {
	if (isset($_SESSION['gebruiker_id'])) {
		return $_SESSION['gebruiker_id'];
	} else {
		return null;
	}
}

function gebruiker_logged_in(){
	if(gebruiker_get_id()){
		return true;
	} else {
		return false;
	}
}
	
