<?php

require("core/sys_get_temp_name.php");

require("core/navigation.php");
require("core/module.php");
require("core/page.php");
require("core/dialog.php");
require("core/template.php");
require("core/gebruiker.php");
require("core/rechten.php");
require("core/core.php");
require("core/validate.php");
require("core/json.php");
require("core/developer_code_mailer.php");
require("core/misc.php");
//require("core/backlinks.php");
//require("core/lib.php");
//require("core/mail.php");

require("core/crud/crud_db.php");

require("core/crud/crud.php");
require("core/crud/crud_edit.php");
require("core/crud/crud_new.php");
require("core/crud/crud_list.php");
require("core/crud/crud_delete.php");
require("core/crud/crud_sortable_list.php");

require("core/crud/crud_dialog.php");
require("core/crud/crud_dialog_edit.php");
require("core/crud/crud_dialog_new.php");
require("core/crud/crud_dialog_list.php");

require("core/widgets/lijst.php");
require("core/widgets/upload_files.php");
require("core/widgets/input_suggest.php");
require("core/widgets/dyn_list.php");
