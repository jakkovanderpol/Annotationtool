<?php

require ("core/includes.php");
require ("lib/includes.php");
require ("db/includes.php");
require ('DB.php');


core_init_session();
core_init_db();

