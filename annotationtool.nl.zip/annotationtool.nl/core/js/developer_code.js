function reload_module( name ){
  new Ajax.Updater(name, '',
  {
    method: 'get',
    parameters: 'm=' + name
  });
}

function create_div( id ) {
	var options = new Hash({
        style: false,
		container: document.body,
		text: ''
    }).extend(arguments[1] || {});
	
	var div = new Element('div', {
	'id': id,
	'html': options.text,
	'class': options.style } ).inject( $(options.container) ); 
	return div;
}

function png( src ) {
	var extra = Object.extend({}, arguments[1] || {});
	
	var str = '';
	
	for( var obj in extra  ) {
		str += obj +"=\"" + extra.obj + "\" ";
	}
		
		
	version=0
	if (navigator.appVersion.indexOf("MSIE")!=-1){
		temp=navigator.appVersion.split("MSIE")
		version=parseFloat(temp[1])
	}

    if( version >= 7.0 || version == 0) {
		str = '<img src="' + src + '" ' + str + ' border="0px">';
	} else {
		str = '<img src="core/img/empty.png" style="filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src=\'' +src+ '\', sizingMethod=\'scale\');" ' + str + ' border="0px" >';
	}
	return str;
}

function showEmptyPopup(id, text){
	var r = confirm(text);
	if(r){
		window.location.href = "?m=course.empty&course_id="+id
	}
}

Infi = {
	eval: function(string) {
		var headList = document.getElementsByTagName('head');
		var headElement = headList[0];
		
		var scriptElement = document.createElement('script');
		
		var attribute = document.createAttribute('type');
		attribute.nodeValue = 'text/javascript';
		scriptElement.setAttributeNode(attribute);
		
		// werkt in IE en FF
		scriptElement.text = string;
		
		// werkt in FF, niet in IE
		// var text = document.createTextNode(string);
		// scriptElement.appendChild(text);
		
		headElement.appendChild(scriptElement);
	},
	
	include: function(src) {
	   var headList = document.getElementsByTagName('head');
	   var headElement = headList[0];
	   
	   var scriptElement = document.createElement('script');
	
	   var attribute = document.createAttribute('type');
	   attribute.nodeValue = 'text/javascript';
	   scriptElement.setAttributeNode(attribute);
	
	   var attribute = document.createAttribute('src');
	   attribute.nodeValue = src;
	   scriptElement.setAttributeNode(attribute);
	
	   headElement.appendChild(scriptElement);
	},
	
	included: new Array(),
	
	includeOnce: function(src) {
		if(Infi.included.indexOf(src) == -1) {
			Infi.include(src);
			Infi.included.push(src);
		}
	},
	
	getWindowDimension: function() {
		var myWidth = 0, myHeight = 0;
		
		if( typeof( window.innerWidth ) == 'number' ) {
			//Non-IE
			myWidth = window.innerWidth;
			myHeight = window.innerHeight;
		} else if( document.documentElement && ( document.documentElement.clientWidth || document.documentElement.clientHeight ) ) {
			//IE 6+ in 'standards compliant mode'
			myWidth = document.documentElement.clientWidth;
			myHeight = document.documentElement.clientHeight;
		} else if( document.body && ( document.body.clientWidth || document.body.clientHeight ) ) {
			//IE 4 compatible
			myWidth = document.body.clientWidth;
			myHeight = document.body.clientHeight;
		}
		
		return { width: myWidth, height: myHeight };
	},
	
	activate: function() {
		var done = false;
		
		var element = $(document.body).getElement('.activate');
		if( element ) {
			element.focus();
		}
	}
};

self.addEvent( 'load', Infi.activate );