// Dialog class for displaying AJAX dialogs

Dialog = {	
	draghandle: false,

	unlock: function() {
		if(!$('lock_div')) {
			var obj = new Element('div', {id: 'lock_div', 'class': 'screen_lock'}).inject( $(document.body) );
		}
		
		$('lock_div' ).setStyle('visibility', 'hidden');   
	},
	
	lock: function() {
		if(!$('lock_div')) {
			var obj = new Element('div', {id: 'lock_div', 'class': 'screen_lock'}).inject( $(document.body) );
		}
		
		$('lock_div').setStyles( {
			width:  Infi.getWindowDimension().width + 'px',
			height: Infi.getWindowDimension().height + 'px'
		} );
		
		$('lock_div' ).setStyle('visibility', 'visible');   
	},
	
	center: function() {
		var width = parseInt($('popup_div').getStyle('width'));
		var height = parseInt($('popup_div').getStyle('height'));
		var left = parseInt((Infi.getWindowDimension().width-width)/2,10);
		var top = parseInt((Infi.getWindowDimension().height-height)/2,10);
		
		$('popup_div').setStyles( {
			left: (left + 'px'),
			top: (top + 'px')
		} );
	},
	
	show: function( str, w, h, left, top ) {		
		Dialog.lock();
		
		if(left == null) left = parseInt((Infi.getWindowDimension().width-w)/2,10);
		if(top == null) top = parseInt((Infi.getWindowDimension().height-h)/2,10);
		
		if(!$('popup_div')) {
			// ik stop hier een iframe achter om te zorgen dat de popup over de inputs eenvalt
			// dit iframe wel de juiste grote geven!
			
			if(Dialog.useIFrame) {
				var obj = new Element('iframe', {id: 'popup_iframe', 'class': 'popup_iframe'}).inject( $(document.body) );
			}
			
			var obj = new Element('div', { id: 'popup_div', 'class': 'popup_div'}).inject( $(document.body) );
			
	//		new Drag( $('popup_div'), {'change' : function() { Dialog.onmove(); } } );
//			$('popup_div').makeResizable();
		} else {
			$('popup_div').setStyles( {	opacity: 1} );
		}
		
		$( 'popup_div' ).set(  'html', str );

		$('popup_div').setStyles( {
			width: (w + 'px'),
			left: (left + 'px'),
			top: (top + 'px')
		} );
		
		$( 'popup_div' ).setStyle('visibility', 'visible');   
		// Event.observe( 'popup_div', 'click', hide_popup, true);
		
		if(Dialog.useIFrame) {
			$( 'popup_iframe' ).setStyle('visibility', 'visible'); 
//			Position.clone( 'popup_div', 'popup_iframe' );
		}
		// 
		var obj =  $( 'popup_div').getElement('h1' );
		if( obj ) {
			if( this.draghandle ) {
				delete this.draghandle;
			}
			this.draghandle= new Drag( $('popup_div'), {'change' : function() { Dialog.onmove(); }, 'handle': obj } );
			obj.setStyles({ cursor: 'move'});
		}
		
		setTimeout(Infi.activate, 0);
	},
	
	hide: function() {		
		if(Dialog.useIFrame) $('popup_iframe' ).setStyle('visibility', 'hidden');    
		
		$('popup_div' ).setStyle('visibility', 'hidden');   
		
		Dialog.unlock();
	},
	
	onmove: function() {
		if(Dialog.useIFrame)  {
			$('popup_iframe').setStyle( { left : $('popup_div').offsetLeft + 'px', top : $('popup_div').offsetTop + 'px' } );
		}
	},
	
	options: {},	
	useIFrame : false,
	
	open: function(url, pars, options) {
		Dialog.options = new Hash({}).extend( options || {} );
		
		Dialog.useIFrame = /MSIE/.test(navigator.userAgent);
		
		var request = new Request({
				url: url,
				method: 'post',
				onSuccess: Dialog.callback
			}).send(pars);
		
	},
	
	replace: function(url, pars) {
		// eventueel komt er een verschil tussen iets openen in hetzelfde popup of een extra popup...

		Dialog.open(url, pars, Dialog.options);
	},
	
	callback: function(request) {
		try {			
			eval('var json = ' + request);
		} catch(e) {
			var json = {action: 'display', html: request.responseText}
		}
		
		var action = json.action;
				
		if(action == 'display') {			
			json.scripts = '';
			var html = json.html.stripScripts(function(script){
				json.scripts = script;
			});
			
		//	Dialog.show(html, 640, 480, 30, 60);
			Dialog.show(html, 520, 480, 30, 60);
			
			$exec(json.scripts);
		} else if(action == 'redirect') {
			var uri = json.uri;
			
			Dialog.replace(uri);
		} else if(action == 'close') {
			if( !$chk(Dialog.options.onClose) ) {
				var doClose = true;
			} else {
				var returnValue = Dialog.options.onClose();
				var doClose = returnValue == null || returnValue;
			}			
			if(doClose) {
				Dialog.hide();
			}
		} else if(action == 'refresh') {
			if(Dialog.options.onRefresh == null) {
				var doRefresh = true;
			} else {
				var returnValue = Dialog.options.onRefresh();
				var doRefresh = returnValue == null || returnValue;
			}
			
			if(doRefresh) {
				document.location.href = document.location.href;
			}
		}
		if (Dialog.options.doCenter) {
			Dialog.center();
		}
	},
	
	post: function(form) {
		Dialog.replace(form.action, $(form).toQueryString() );
	},
	
	reopen: function() {
		var useIFrame = /MSIE/.test(navigator.userAgent);
		
		$('popup_div').morph( {opacity:1});
		Dialog.lock();
	},
	
	suspend: function() {
		$('popup_div').morph( {opacity:0.85});
		Dialog.unlock();
	},
	
	events: []
};