<?php

/**
 * This is purely here for identify reasons on some subclasses
 * @package Swift
 * @author Chris Corbyn <chris@w3style.co.uk>
 */
abstract class Swift_AddressContainer {}
