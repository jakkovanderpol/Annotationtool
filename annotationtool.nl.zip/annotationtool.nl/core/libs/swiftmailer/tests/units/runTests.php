<html>
	<head>
		<title>Swift Mailer Unit Test suite</title>
	</head>
	<frameset cols="30%,70%">
		<frame name="list" src="./support-files/list_panel.php">
		<frame name="runner" src="./support-files/test_runner.php">
	</frameset>
</html>
