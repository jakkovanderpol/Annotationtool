<?php

require_once dirname(__FILE__) . "/BasicTestSuite.php";

$suite = BasicTestSuite::getInstance();
$suite->executeList();
