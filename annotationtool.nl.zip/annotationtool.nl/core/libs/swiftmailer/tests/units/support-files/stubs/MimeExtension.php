<?php

class MimeExtension extends Swift_Message_Mime
{
  public function preBuild() {}
  public function getLevel() {}
}
